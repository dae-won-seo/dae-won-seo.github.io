clc; clear all; close all;
rng(0);

relerr = @(x, xt) norm(x - xt) / norm(xt);

%% Part1: 
% solve Ax = b...
clc;
A = [1, 1; 1, 1];
b = [2; 2.001];

% [U,S,V] = svd(A);
x = pinv(A)*b;

% A 를 아주 조금만 흔들어 보기
c = 0.00001;
dA = c*randn(2,2);
x2 = pinv(A+dA)*b;

fprintf('원래 해   : [%.4f  %.4f]\n', x(1), x(2));
fprintf('[%.5f] 만큼 흔든 뒤   : [%.4f  %.4f]\n', c, x2(1), x2(2));

svd(pinv(A))
svd(pinv(A+dA))


%% part2: Hilbert matrix 선언
clc;

n  = 10;
H  = hilb(n);
x_true = ones(n, 1);    % true answer는 [1 1 1 1...]벡터임
b  = H * x_true;    % true system

fprintf('cond(H) = %.3g\n\n', cond(H));

%% : 데이터에 노이즈가 있으면??
clc;
noise = 1e-8 * randn(n,1);      % 아주 작은 노이즈 첨가
bn = b + noise;

xn = inv(H)*bn;         % 작은 노이즈때문에 answer가 폭발함

fprintf('%-16s %12.4g\n', 'error of xn', relerr(xn, x_true));


s = svd(H);
fprintf('\n특이값과 노이즈 크기 비교 (노이즈 = %.1e)\n', norm(noise));
for k = 1:n
    mark = '';
    if s(k) < norm(noise), mark = '  <- 노이즈에 잠김'; end
    fprintf('  s%-2d = %.3e%s\n', k, s(k), mark);
end

% H는 아주 작은 (아무 영향이 없는) 특이값을 가지고 있는데
% 이것들이 역행렬에서는 1/s로 작용해서 엄청 커진다 => 쓸모없는 답을 준다

%% 솔루션: 작은 특이값 버리기
% pinv(H, tol) 은 tol 보다 작은 특이값을 0 으로 취급한다

fprintf('\n%10s %10s %12s\n', 'tol', '쓴 개수', '상대오차');
for tol = [1e-3 1e-4 1e-5 1e-6 1e-7 1e-8 1e-10 1e-14]

    xk = pinv(H, tol) * bn;

    fprintf('%10.0e %10d %12.4g\n', tol, sum(s > tol), relerr(xk, x_true));
end

% 특이값 10개를 다 쓸 때 => 오차가 크다
% 특이값을 일부 버렸더니 정확해졌다