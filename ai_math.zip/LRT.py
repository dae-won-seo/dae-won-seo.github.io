import matplotlib
matplotlib.use('Agg')
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal

np.random.seed(0)

mu0 = np.array([-1, 1])
mu1 = np.array([ 1, -1])
Sigma = np.array([[1.0, 0],
                  [0, 1.0]])


X0 = np.random.multivariate_normal(mu0, Sigma, 100000)
X1 = np.random.multivariate_normal(mu1, Sigma, 100000)
np.save('X0.npy', X0)
np.save('X1.npy', X1)


x = np.linspace(-6, 6, 400)
y = np.linspace(-5, 5, 400)
XX, YY = np.meshgrid(x, y)
pos = np.c_[XX.ravel(), YY.ravel()]

rv0 = multivariate_normal(mu0, Sigma)
rv1 = multivariate_normal(mu1, Sigma)

Z0 = rv0.pdf(pos).reshape(XX.shape)
Z1 = rv1.pdf(pos).reshape(XX.shape)
log_lrt = (rv1.logpdf(pos) - rv0.logpdf(pos)).reshape(XX.shape)

fig, ax = plt.subplots(figsize=(6, 5))


ax.scatter(X0[:, 0], X0[:, 1], c='steelblue', s=10, alpha=0.4,
           label=r'$H_0: \mu_0=(-1.5, 1), \pi_0=0.5$')
ax.scatter(X1[:, 0], X1[:, 1], c='tomato', s=10, alpha=0.4,
           label=r'$H_1: \mu_1=(1, -1.5), \pi_1=0.5$')

ax.contour(XX, YY, Z0, levels=5, colors='black', linewidths=0.8)
ax.contour(XX, YY, Z1, levels=5, colors='black',    linewidths=0.8)


ax.contour(XX, YY, log_lrt, levels=[0], colors='black', linewidths=0.8)
ax.plot([], [], 'k-', lw=1, label=r'LRT boundary')


ax.plot(*mu0, 'x', color='black', ms=10, mew=2)
ax.plot(*mu1, 'x', color='black',    ms=10, mew=2)


ax.set_xlim(-6, 6)
ax.set_ylim(-5, 5)
ax.set_xlabel(r'$x_1$', fontsize=12)
ax.set_ylabel(r'$x_2$', fontsize=12)
ax.set_title(r'Likelihood Ratio Test', fontsize=12)
ax.legend(fontsize=9, loc='upper right')
ax.set_aspect('equal')
ax.grid(True, linestyle='--', alpha=0.4)

plt.tight_layout()
plt.savefig('Likelihood_Ratio_Test_sample.png', dpi=150, bbox_inches='tight')
print("saved")