clc; clear all; close all;

T = readtable('shapes_data.csv');

%% visualize...
data = T(T.shape == "arrow", :)     % F or arrow
plot(data.x, data.y, '-o', 'LineWidth', 2);
hold on; axis([-10, 10, -10, 10]); grid on;


%% rotation transform
clc;

% 회전변환
degree = 30;
% A = [cosd(degree), -sind(degree); sind(degree), cosd(degree)];
A = [1, 0; 0, 0];

% X축 or Y축 projection (determinant 는 0이다)
% A = [1, 0; 0, 0];
% A = [0, 0; 0, 1];

% check..
fprintf('Determinant of A is %.4f \n', det(A) );
fprintf('Inner product of 1st and 2nd rows is %.4f \n', dot( A(1,:), A(2,:) ) );


data_original = [data.x, data.y]';
data_after = A*data_original;
plot(data_after(1,:), data_after(2,:), '-x');

% data_after2 = A*data_after;
% plot(data_after2(1,:), data_after2(2,:), '-d');

%% inverse transform
% Calculate the inverse transformation matrix
A_inv = pinv(A)
% Apply the inverse transformation to the transformed data
data_recovered = A_inv * data_after;
plot(data_recovered(1,:), data_recovered(2,:), '-s');
legend('Original Data', 'Transformed Data', 'Recovered Data');