import matplotlib
matplotlib.use('Agg')
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim

np.random.seed(0)
torch.manual_seed(0)


X0 = np.load('X0.npy')
X1 = np.load('X1.npy')
X  = np.vstack([X0, X1]).astype(np.float32)
y  = np.array([0]*len(X0) + [1]*len(X1), dtype=np.float32)


model = nn.Sequential(
    nn.Linear(2, 16), nn.ReLU(),
    nn.Linear(16, 16), nn.ReLU(),
    nn.Linear(16, 1), nn.Sigmoid()
)

Xt = torch.from_numpy(X)
yt = torch.from_numpy(y)

optimizer = optim.Adam(model.parameters(), lr=1e-2)
criterion = nn.BCELoss()


for epoch in range(1000):
    model.train()
    optimizer.zero_grad()
    pred = model(Xt).squeeze()
    loss = criterion(pred, yt)
    loss.backward()
    optimizer.step()


x1 = np.linspace(-6, 6, 400)
x2 = np.linspace(-5, 5, 400)
XX, YY = np.meshgrid(x1, x2)
pos = np.c_[XX.ravel(), YY.ravel()].astype(np.float32)

model.eval()
with torch.no_grad():
    NN_Z = model(torch.from_numpy(pos)).squeeze().numpy().reshape(XX.shape)

fig, ax = plt.subplots(figsize=(6, 5))

ax.scatter(X0[:, 0], X0[:, 1], c='steelblue', s=10, alpha=0.4, label=r'$H_0$ samples')
ax.scatter(X1[:, 0], X1[:, 1], c='tomato',    s=10, alpha=0.4, label=r'$H_1$ samples')

ax.contour(XX, YY, NN_Z, levels=[0.5], colors='black', linewidths=0.8)
ax.plot([], [], color='black', lw=1, label=r'BCE boundary')


ax.set_xlim(-6, 6)
ax.set_ylim(-5, 5)
ax.set_xlabel(r'$x_1$', fontsize=12)
ax.set_ylabel(r'$x_2$', fontsize=12)
ax.set_title('Machine Learning Classifiers (BCE)', fontsize=12)
ax.legend(fontsize=9, loc='upper right')
ax.set_aspect('equal')
ax.grid(True, linestyle='--', alpha=0.4)

plt.tight_layout()
plt.savefig('Machine_Learning_Classifiers.png', dpi=150, bbox_inches='tight')
print("saved")
